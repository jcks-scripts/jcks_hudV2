local ESX, QBCore, QBX = nil, nil, nil

local ESX_Started = GetResourceState("es_extended") == "started"
local QBCore_Started = GetResourceState("qb-Core") == "started"
local QBX_Started = GetResourceState("qbx_Core") == "started"

if ESX_Started then
    ESX = exports["es_extended"]:getSharedObject()
elseif QBCore_Started then
    QBCore = exports["qb-Core"]:GetCoreObject()
elseif QBX_Started then
    QBX = exports["qbx_Core"]:GetCoreObject()
else
    print("Unsupported framework. Supported frameworks: ESX, QBCore, QBX")
end

local isHudVisible, seatbeltOn, status = true, false, "OFF"
local minimap = RequestScaleformMovie("minimap")

local function loadMinimap()
    SetRadarBigmapEnabled(true, false)
    Citizen.Wait(500)
    SetRadarBigmapEnabled(false, false)
end

local function playSound(type)
    local sound = (type == "buckle") and "SELECT" or "CANCEL"
    PlaySoundFrontend(-1, sound, "HUD_LIQUOR_STORE_SOUNDSET", false)
end

local function toggleSeatbelt(makeSound, toggle)
    if toggle == nil then
        toggle = not seatbeltOn
    end

    if toggle then
        if makeSound then playSound("buckle") end
        SetFlyThroughWindscreenParams(10000.0, 10000.0, 17.0, 500.0)
    else
        if makeSound then playSound("unbuckle") end
        SetFlyThroughWindscreenParams(Main.Seatbelt.ejectVelocity, Main.Seatbelt.unknownEjectVelocity, Main.Seatbelt.unknownModifier, Main.Seatbelt.minDamage)
    end
    seatbeltOn = toggle
end

RegisterCommand("seatbelt", function()
    local title = ""
    local message = ""
    toggleSeatbelt(true)
    if seatbeltOn then
        local message = 'You are now buckled up!' 
    else
        local message = 'You have unbuckled your seatbelt!' 
    end
    SendNotification(title, message)
    status = seatbeltOn and "ON" or "OFF"
end, false)

local function updatePlayerStatus()
    local player = PlayerPedId()
    local health = math.max(0, math.min(100, GetEntityHealth(player) - 100))
    local armor = math.max(0, math.min(100, GetPedArmour(player)))
    local stamina = math.max(0, math.min(100, 100 - GetPlayerSprintStaminaRemaining(player)))

    SendNUIMessage({
        type = "StatusHUD",
        health = health,
        armor = armor,
        stamina = stamina
    })
end

local function updatePlayerNeeds()
    if ESX then
        TriggerEvent('esx_status:getStatus', 'hunger', function(hungerStatus)
            TriggerEvent('esx_status:getStatus', 'thirst', function(thirstStatus)
                SendNUIMessage({
                    type = "NeedsHUD",
                    food = math.max(0, math.min(100, math.floor(hungerStatus.getPercent()))),
                    water = math.max(0, math.min(100, math.floor(thirstStatus.getPercent())))
                })
            end)
        end)
    elseif QBCore then
        local hunger, thirst = 0, 0
        TriggerEvent('hud:client:UpdateNeeds', function(newHunger, newThirst)
            hunger, thirst = newHunger, newThirst
        end)
        SendNUIMessage({
            type = "NeedsHUD",
            food = math.max(0, math.min(100, hunger)),
            water = math.max(0, math.min(100, thirst))
        })
    end
end

local function updateCarHud()
    local player = PlayerPedId()
    local isInVehicle = IsPedInAnyVehicle(player, false)
    local vehicle = isInVehicle and GetVehiclePedIsIn(player, false) or nil
    local speed = isInVehicle and math.floor(GetEntitySpeed(vehicle) * 3.6) or 0
    local fuel = isInVehicle and math.floor(Main.FuelExport(vehicle)) or 0
    local coords = GetEntityCoords(player)
    local heading = GetEntityHeading(player)
    local direction = (heading >= 315 or heading < 45) and "North" or
                      (heading >= 45 and heading < 135) and "East" or
                      (heading >= 135 and heading < 225) and "South" or "West"

    local streetHash, crossingHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local streetName = streetHash and streetHash ~= 0 and GetStreetNameFromHashKey(streetHash) or "Unknown Street"
    if crossingHash and crossingHash ~= 0 then
        streetName = streetName .. " / " .. GetStreetNameFromHashKey(crossingHash)
    end

    SendNUIMessage({
        type = "CarHUD",
        isinvehicle = isInVehicle,
        speed = speed,
        fuel = fuel,
        street = streetName,
        compass = direction,
        seatbelt = status
    })
end

Citizen.CreateThread(function()
    loadMinimap()
    while true do
        Wait(500)
        BeginScaleformMovieMethod(minimap, "SETUP_HEALTH_ARMOUR")
        ScaleformMovieMethodAddParamInt(3)
        EndScaleformMovieMethod()
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(200)
        updatePlayerStatus()
        updatePlayerNeeds()
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(200)
        updateCarHud()

        local isPauseMenuActive = IsPauseMenuActive()
        if isPauseMenuActive and isHudVisible then
            isHudVisible = false
            SendNUIMessage({ type = "hideHUD" })
        elseif not isPauseMenuActive and not isHudVisible then
            isHudVisible = true
            SendNUIMessage({ type = "showHUD" })
        end

        DisplayRadar(IsPedInAnyVehicle(PlayerPedId(), false))
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(0)
        if seatbeltOn then
            DisableControlAction(0, 75, true)
            DisableControlAction(27, 75, true)
        end
    end
end)

function SendNotification(title, message)
    local NotificationType = Main.NotificationType
    local NotificationTitle = title
    local NotificationMessage = message
    if NotificationType == "ESX" then
        TriggerClientEvent('esx:showNotification', source, NotificationMessage, 'info', 2000)
    elseif NotificationType == "QBCORE" then
        QBCore.Functions.Notify(NotificationTitle, "primary", 2000)
    elseif NotificationType == "OX" then
        lib.notify({
            title = NotificationTitle,
            description = NotificationMessage,
            type = 'inform'
        })
    elseif NotificationType == "CUSTOM" then
        SendCustomNotification()
    end
end

local NeedsAlert = Main.NeedsAlert
local watertitle = Main.WaterTitle
local watermessage = Main.WaterMessage
local foodtitle = Main.FoodTitle 
local foodmessage = Main.FoodMessage


Citizen.CreateThread(function()
    while true do
        local CheckTime = Main.CheckTime
        Citizen.Wait(CheckTime)
if NeedsAlert then
    if ESX then
        TriggerEvent('esx_status:getStatus', 'hunger', function(status)
            local FoodAlertValue = Main.FoodAlertValue
            if status.val < FoodAlertValue  then
                SendNotification(foodtitle, foodmessage)
            end
        end)

        TriggerEvent('esx_status:getStatus', 'thirst', function(status)
            local WaterAlertValue = Main.WaterAlertValue
            if status.val < WaterAlertValue then
                SendNotification(watertitle, watermessage)
            end
        end)
    elseif QBCore then
        local hunger, thirst = 0, 0
        TriggerEvent('hud:client:UpdateNeeds', function(newHunger, newThirst)
            hunger, thirst = newHunger, newThirst
        end)
        local WaterAlertValue = Main.WaterAlertValue
        if thirst == WaterAlertValue then
        SendNotification(watertitle, watermessage)
        end
        local FoodAlertValue = Main.FoodAlertValue
        if hunger == FoodAlertValue then
        SendNotification(foodtitle, foodmessage)
        end
elseif QBX then
    local hunger, thirst = 0, 0
    TriggerEvent('hud:client:UpdateNeeds', function(newHunger, newThirst)
        hunger, thirst = newHunger, newThirst
    end)
    local WaterAlertValue = Main.WaterAlertValue
    if thirst == WaterAlertValue then
    SendNotification(watertitle, watermessage)
    end
    local FoodAlertValue = Main.FoodAlertValue
    if hunger == FoodAlertValue then
    SendNotification(foodtitle, foodmessage)
    end
end
end
end
end)