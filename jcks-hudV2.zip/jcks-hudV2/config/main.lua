Main = {}

Main.NotificationType = "ESX"  -- Type of Notification, Types: ESX, QBCORE, OX, CUSTOM
Main.NeedsAlert = false
Main.WaterAlertValue = 300000
Main.FoodAlertValue = 300000
Main.CheckTime = 30000

function SendCustomNotification()
    -- If you want to use custom notify write your code here.
end

function GetFuel(vehicle)
    -- Rewrite GetVehicleFuelLevel(vehicle) to our own export or trigger if you using other script.
    return GetVehicleFuelLevel(vehicle)
end

Main.Seatbelt = {
    ejectVelocity = 45.0,
    unknownEjectVelocity = 10.0,
    unknownModifier = 5.0,
    minDamage = 300.0
}

