fx_version "cerulean"
game "gta5"

author "JCKS-SCRIPTS"
description "Advanced Hud"
version "2.0"

lua54 "yes"

ui_page 'ui/ui.html'

files {
    'ui/*.png',
    'ui/*',
}

shared_scripts {
    "config/main.lua"
}

client_scripts {
    "client/main.lua"
}